# RSI Algo Trader — Deployment Guide
## Deploy to Netlify with Invite-Only Access Control

---

## What you get

- A **public URL** (e.g. `https://rsi-algo-trader.netlify.app`)
- The login gate is public — anyone can see the request form
- **Only people YOU invite** by email can log in and reach the dashboard
- You manage access from Netlify's dashboard — no code changes needed

---

## Step 1 — Create a free Netlify account

Go to [netlify.com](https://netlify.com) and sign up (free plan is enough).

---

## Step 2 — Deploy the site

### Option A — Drag & Drop (easiest, no Git needed)

1. Go to [app.netlify.com](https://app.netlify.com)
2. Click **"Add new site" → "Deploy manually"**
3. Drag and drop the entire `rsi-trader-deploy` folder onto the upload area
4. Netlify gives you a live URL instantly (e.g. `https://random-name.netlify.app`)
5. Optional: rename it under **Site configuration → Site details → Change site name**

### Option B — GitHub (recommended for updates)

1. Push this folder to a private GitHub repo
2. In Netlify: **Add new site → Import an existing project → GitHub**
3. Select your repo, set publish directory to `public`, click **Deploy**

---

## Step 3 — Enable Netlify Identity (the access control)

1. In your Netlify dashboard, go to **Project configuration → Identity**
2. Click **Enable Identity**
3. Under **Registration preferences**, select **"Invite only"**
   - This means nobody can sign up on their own — only people you invite
4. Under **External providers** (optional): enable Google login for convenience

---

## Step 4 — Invite your first user (yourself to test)

1. Go to **Project configuration → Identity → Users**
2. Click **"Invite users"**
3. Enter your own email → click Send
4. Check your inbox → click the invite link → set a password
5. Go to your site URL → log in → you should land on the dashboard

---

## Step 5 — Approving new users

When someone submits their email via the "Request access" form on your site:
- You get a notification (once you set `ADMIN_EMAIL` in env vars)
- Go to **Project configuration → Identity → Users → Invite users**
- Enter their email → they receive an invite link
- They click it, set a password, and can now access the dashboard

**To revoke access:** Go to Identity → Users → click the user → Delete.

---

## Step 6 — Set your admin email (for access request notifications)

1. Go to **Project configuration → Environment variables**
2. Add:
   - Key: `ADMIN_EMAIL`
   - Value: your email address (e.g. `yourname@gmail.com`)
3. Redeploy (Netlify does this automatically after saving)

---

## Step 7 — Custom domain (optional)

1. Go to **Project configuration → Domain management → Add a domain**
2. Enter e.g. `trader.yourdomain.com`
3. Follow the DNS instructions — SSL is automatic

---

## How access control works

```
Visitor hits your URL
        │
        ▼
   index.html (public login gate)
        │
   Has invite?  ──NO──▶  "Request access" form ──▶ You get notified
        │                                            You decide to invite or ignore
       YES
        │
        ▼
   Netlify Identity checks JWT token
        │
        ▼
   /dashboard.html  ✓  (only reachable when logged in)
```

---

## Managing users day-to-day

| Action | Where |
|--------|-------|
| Invite a new user | Identity → Users → Invite users |
| Remove a user | Identity → Users → [user] → Delete |
| See who's logged in | Identity → Users (shows last login) |
| Reset someone's password | Identity → Users → [user] → Send password reset |
| Block access immediately | Identity → Users → [user] → Delete |

---

## File structure

```
rsi-trader-deploy/
├── public/
│   ├── index.html          ← Login gate (public)
│   └── dashboard.html      ← Your trading dashboard (protected)
├── netlify/
│   └── functions/
│       └── request-access.js  ← Notifies you when someone requests access
└── netlify.toml            ← Netlify config
```

---

## Security notes

- Netlify Identity uses **JWTs** — tokens are verified server-side
- The dashboard is not served to unauthenticated users
- Access tokens expire (configurable under Identity settings)
- All traffic is HTTPS by default on Netlify
- Your Zerodha API key is entered client-side and never stored on the server

---

*Built with Netlify Identity · Free plan supports up to 1,000 Identity users*
